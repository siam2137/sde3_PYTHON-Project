-- CampusFlow schema and demo data (MySQL 8.0.16+)
-- Run this file in phpMyAdmin or the MySQL command line.
CREATE DATABASE IF NOT EXISTS campusflow CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE campusflow;
SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;
DROP TABLE IF EXISTS course_tasks;
DROP TABLE IF EXISTS course_replies;
DROP TABLE IF EXISTS course_posts;
DROP TABLE IF EXISTS deadlines;
DROP TABLE IF EXISTS session_requests;
DROP TABLE IF EXISTS study_sessions;
DROP TABLE IF EXISTS user_courses;
DROP TABLE IF EXISTS courses;
DROP TABLE IF EXISTS users;
SET FOREIGN_KEY_CHECKS = 1;

CREATE TABLE users (
  id INT NOT NULL AUTO_INCREMENT,
  name VARCHAR(100) NOT NULL,
  email VARCHAR(190) NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  department VARCHAR(100) NOT NULL DEFAULT '',
  semester VARCHAR(40) NOT NULL DEFAULT '',
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_users_email (email)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE courses (
  id INT NOT NULL AUTO_INCREMENT,
  course_code VARCHAR(30) NOT NULL,
  course_title VARCHAR(180) NOT NULL,
  semester_label VARCHAR(40) NOT NULL DEFAULT '',
  PRIMARY KEY (id),
  UNIQUE KEY uq_courses_code (course_code)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE user_courses (
  user_id INT NOT NULL,
  course_id INT NOT NULL,
  PRIMARY KEY (user_id, course_id),
  CONSTRAINT fk_user_courses_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  CONSTRAINT fk_user_courses_course FOREIGN KEY (course_id) REFERENCES courses(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE study_sessions (
  id INT NOT NULL AUTO_INCREMENT,
  creator_id INT NOT NULL,
  course_id INT NOT NULL,
  title VARCHAR(160) NOT NULL,
  topic TEXT NOT NULL,
  location VARCHAR(180) NOT NULL DEFAULT 'Online',
  session_datetime DATETIME NOT NULL,
  max_members INT NOT NULL DEFAULT 4,
  status VARCHAR(16) NOT NULL DEFAULT 'open',
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY ix_sessions_creator (creator_id),
  KEY ix_sessions_course_datetime (course_id, session_datetime),
  KEY ix_sessions_datetime (session_datetime),
  KEY ix_sessions_status (status),
  CONSTRAINT ck_session_min_members CHECK (max_members >= 2),
  CONSTRAINT ck_session_status CHECK (status IN ('open','full','closed')),
  CONSTRAINT fk_sessions_creator FOREIGN KEY (creator_id) REFERENCES users(id) ON DELETE CASCADE,
  CONSTRAINT fk_sessions_course FOREIGN KEY (course_id) REFERENCES courses(id) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE session_requests (
  id INT NOT NULL AUTO_INCREMENT,
  session_id INT NOT NULL,
  requester_id INT NOT NULL,
  status VARCHAR(16) NOT NULL DEFAULT 'pending',
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_session_requester (session_id, requester_id),
  KEY ix_session_requests_status (session_id, status),
  CONSTRAINT ck_request_status CHECK (status IN ('pending','accepted','declined')),
  CONSTRAINT fk_requests_session FOREIGN KEY (session_id) REFERENCES study_sessions(id) ON DELETE CASCADE,
  CONSTRAINT fk_requests_requester FOREIGN KEY (requester_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE deadlines (
  id INT NOT NULL AUTO_INCREMENT,
  user_id INT NOT NULL,
  course_id INT NOT NULL,
  title VARCHAR(180) NOT NULL,
  type VARCHAR(20) NOT NULL,
  due_datetime DATETIME NOT NULL,
  is_completed TINYINT(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (id),
  KEY ix_deadlines_user_due (user_id, due_datetime),
  KEY ix_deadlines_due (due_datetime),
  CONSTRAINT ck_deadline_type CHECK (type IN ('exam','assignment','quiz','project')),
  CONSTRAINT fk_deadlines_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  CONSTRAINT fk_deadlines_course FOREIGN KEY (course_id) REFERENCES courses(id) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE course_posts (
  id INT NOT NULL AUTO_INCREMENT,
  user_id INT NOT NULL,
  course_id INT NOT NULL,
  post_type VARCHAR(20) NOT NULL,
  title VARCHAR(180) NOT NULL,
  body TEXT NOT NULL,
  resource_url VARCHAR(2048) NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY ix_course_posts_course_created (course_id, created_at),
  CONSTRAINT ck_post_type CHECK (post_type IN ('question','note_link')),
  CONSTRAINT fk_posts_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  CONSTRAINT fk_posts_course FOREIGN KEY (course_id) REFERENCES courses(id) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE course_replies (
  id INT NOT NULL AUTO_INCREMENT,
  post_id INT NOT NULL,
  user_id INT NOT NULL,
  body TEXT NOT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY ix_course_replies_post (post_id),
  CONSTRAINT fk_replies_post FOREIGN KEY (post_id) REFERENCES course_posts(id) ON DELETE CASCADE,
  CONSTRAINT fk_replies_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE course_tasks (
  id INT NOT NULL AUTO_INCREMENT,
  user_id INT NOT NULL,
  course_id INT NOT NULL,
  title VARCHAR(180) NOT NULL,
  is_done TINYINT(1) NOT NULL DEFAULT 0,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY ix_tasks_user_course (user_id, course_id),
  CONSTRAINT fk_tasks_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  CONSTRAINT fk_tasks_course FOREIGN KEY (course_id) REFERENCES courses(id) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- All three demo accounts use the same password: Campus123!
-- Hash format is Werkzeug-compatible PBKDF2-SHA256 (600,000 iterations).
INSERT INTO users (id, name, email, password_hash, department, semester) VALUES
(1, 'Siam Ahmed', 'siam@campusflow.test', 'pbkdf2:sha256:600000$campusflow2026$e08e0ed299380e4e8bf2e0ebd370fecd39eca410a5901c4e43d2efbec5201787', 'Computer Science & Engineering', '3rd Semester'),
(2, 'Nadia Rahman', 'nadia@campusflow.test', 'pbkdf2:sha256:600000$campusflow2026$e08e0ed299380e4e8bf2e0ebd370fecd39eca410a5901c4e43d2efbec5201787', 'Computer Science & Engineering', '3rd Semester'),
(3, 'Arif Hasan', 'arif@campusflow.test', 'pbkdf2:sha256:600000$campusflow2026$e08e0ed299380e4e8bf2e0ebd370fecd39eca410a5901c4e43d2efbec5201787', 'Computer Science & Engineering', '4th Semester');

INSERT INTO courses (id, course_code, course_title, semester_label) VALUES
(1, 'CSE3292', 'Software Engineering', '3rd Year'),
(2, 'CSE2101', 'Data Structures and Algorithms', '2nd Year'),
(3, 'MAT1205', 'Linear Algebra', '1st Year'),
(4, 'CSE2203', 'Database Management Systems', '2nd Year'),
(5, 'ENG1101', 'English Communication', '1st Year');

INSERT INTO user_courses (user_id, course_id) VALUES
(1,1),(1,2),(1,3),(1,4),
(2,1),(2,2),(2,5),
(3,1),(3,3),(3,4);

INSERT INTO study_sessions (id, creator_id, course_id, title, topic, location, session_datetime, max_members, status) VALUES
(1, 2, 1, 'Software Engineering revision circle', 'UML diagrams, use cases and SDLC examples', 'Library, Group Study Room 2', DATE_ADD(NOW(), INTERVAL 26 HOUR), 5, 'open'),
(2, 3, 4, 'SQL practice before lab', 'JOINs, GROUP BY, subqueries and normalization', 'Online — Google Meet', DATE_ADD(NOW(), INTERVAL 2 DAY), 4, 'open');

INSERT INTO session_requests (id, session_id, requester_id, status) VALUES
(1, 1, 1, 'pending'),
(2, 2, 1, 'accepted');

INSERT INTO deadlines (user_id, course_id, title, type, due_datetime, is_completed) VALUES
(1, 1, 'Use case diagram submission', 'assignment', DATE_ADD(NOW(), INTERVAL 26 HOUR), 0),
(1, 2, 'Stack and Queue quiz', 'quiz', DATE_ADD(NOW(), INTERVAL 44 HOUR), 0),
(1, 3, 'Midterm examination', 'exam', DATE_ADD(NOW(), INTERVAL 6 DAY), 0),
(1, 4, 'ERD project milestone', 'project', DATE_ADD(NOW(), INTERVAL 12 DAY), 0);

INSERT INTO course_posts (id, user_id, course_id, post_type, title, body, resource_url) VALUES
(1, 2, 1, 'question', 'What is the practical difference between verification and validation?', 'I understand the definitions, but could someone share a simple software project example that makes the difference clear?', NULL),
(2, 3, 4, 'note_link', 'My DBMS normalization notes', 'I made a short revision sheet covering 1NF, 2NF, 3NF and BCNF.', 'https://example.com/dbms-normalization-notes');

INSERT INTO course_replies (post_id, user_id, body) VALUES
(1, 1, 'For example, verification checks whether the design follows the specification; validation checks whether the finished system solves the user''s actual problem.');

INSERT INTO course_tasks (user_id, course_id, title, is_done) VALUES
(1, 1, 'Revise SDLC models', 0),
(1, 2, 'Practice 5 stack problems', 0),
(1, 4, 'Review database normalization', 1);
