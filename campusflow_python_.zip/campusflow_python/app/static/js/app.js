document.addEventListener('DOMContentLoaded', () => {
  document.querySelectorAll('form[data-confirm]').forEach((form) => {
    form.addEventListener('submit', (event) => {
      const promptText = form.dataset.confirm || 'Are you sure?';
      if (!window.confirm(promptText)) event.preventDefault();
    });
  });

  // Set useful lower bounds for future event and session date inputs.
  const now = new Date();
  const localDateTime = new Date(now.getTime() - now.getTimezoneOffset() * 60000)
    .toISOString().slice(0, 16);
  document.querySelectorAll('input[type="datetime-local"]').forEach((input) => {
    input.min = localDateTime;
  });
});
