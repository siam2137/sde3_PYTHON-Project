from urllib.parse import urlparse, urljoin
from flask import Blueprint, flash, g, redirect, render_template, request, session, url_for
from sqlalchemy import select
from .extensions import db
from .models import Course, User

bp = Blueprint("auth", __name__)


def safe_redirect_target(target: str | None) -> bool:
    if not target:
        return False
    ref = urlparse(request.host_url)
    test = urlparse(urljoin(request.host_url, target))
    return test.scheme in {"http", "https"} and ref.netloc == test.netloc


@bp.route("/register", methods=["GET", "POST"])
def register():
    if g.current_user:
        return redirect(url_for("main.dashboard"))
    courses = db.session.scalars(select(Course).order_by(Course.course_code)).all()
    if request.method == "POST":
        name = request.form.get("name", "").strip()
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")
        department = request.form.get("department", "").strip()
        semester = request.form.get("semester", "").strip()
        course_ids = request.form.getlist("course_ids", type=int)
        errors = []
        if not name or len(name) > 100:
            errors.append("Enter your name (maximum 100 characters).")
        if "@" not in email or len(email) > 190:
            errors.append("Enter a valid email address.")
        if len(password) < 8:
            errors.append("Your password must contain at least 8 characters.")
        if db.session.scalar(select(User.id).where(User.email == email)):
            errors.append("An account with that email already exists.")
        if not errors:
            user = User(name=name, email=email, department=department[:100], semester=semester[:40])
            user.set_password(password)
            if course_ids:
                user.courses = db.session.scalars(select(Course).where(Course.id.in_(set(course_ids)))).all()
            db.session.add(user)
            db.session.commit()
            session.clear()
            session["user_id"] = user.id
            flash("Your CampusFlow account is ready. Welcome!", "success")
            return redirect(url_for("main.dashboard"))
        for error in errors:
            flash(error, "danger")
    return render_template("auth/register.html", courses=courses)


@bp.route("/login", methods=["GET", "POST"])
def login():
    if g.current_user:
        return redirect(url_for("main.dashboard"))
    if request.method == "POST":
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")
        user = db.session.scalar(select(User).where(User.email == email))
        if user and user.check_password(password):
            session.clear()
            session["user_id"] = user.id
            flash(f"Welcome back, {user.name.split()[0]}!", "success")
            target = request.args.get("next") or request.form.get("next")
            return redirect(target if safe_redirect_target(target) else url_for("main.dashboard"))
        flash("The email or password you entered is incorrect.", "danger")
    return render_template("auth/login.html", next=request.args.get("next", ""))


@bp.post("/logout")
def logout():
    session.clear()
    flash("You have been logged out.", "info")
    return redirect(url_for("auth.login"))
