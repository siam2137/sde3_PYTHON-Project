from datetime import timedelta
from flask import Blueprint, flash, g, redirect, render_template, request, url_for
from sqlalchemy import select
from .extensions import db
from .models import Course, CourseTask, Deadline, StudySession
from .security import login_required
from .timeutils import local_now

bp = Blueprint("main", __name__)


@bp.get("/")
@bp.get("/dashboard")
@login_required
def dashboard():
    now = local_now()
    window_end = now + timedelta(hours=48)
    deadlines_48 = db.session.scalars(
        select(Deadline).where(
            Deadline.user_id == g.current_user.id,
            Deadline.is_completed.is_(False),
            Deadline.due_datetime >= now,
            Deadline.due_datetime <= window_end,
        ).order_by(Deadline.due_datetime)
    ).all()
    upcoming = db.session.scalars(
        select(Deadline).where(
            Deadline.user_id == g.current_user.id,
            Deadline.is_completed.is_(False),
            Deadline.due_datetime >= now,
        ).order_by(Deadline.due_datetime).limit(6)
    ).all()
    courses = sorted(g.current_user.courses, key=lambda item: item.course_code)
    course_ids = [course.id for course in courses]
    sessions = []
    if course_ids:
        sessions = db.session.scalars(
            select(StudySession).where(
                StudySession.course_id.in_(course_ids),
                StudySession.status == "open",
                StudySession.session_datetime >= now,
            ).order_by(StudySession.session_datetime).limit(4)
        ).all()
    task_items = db.session.scalars(
        select(CourseTask).where(CourseTask.user_id == g.current_user.id)
        .order_by(CourseTask.is_done, CourseTask.created_at.desc()).limit(8)
    ).all()
    pending_tasks = db.session.scalar(
        select(db.func.count(CourseTask.id)).where(
            CourseTask.user_id == g.current_user.id, CourseTask.is_done.is_(False)
        )
    ) or 0
    return render_template(
        "dashboard.html", deadlines_48=deadlines_48, upcoming=upcoming,
        courses=courses, sessions=sessions, pending_tasks=pending_tasks, task_items=task_items, now=now,
    )


@bp.route("/profile", methods=["GET", "POST"])
@login_required
def profile():
    all_courses = db.session.scalars(select(Course).order_by(Course.course_code)).all()
    if request.method == "POST":
        name = request.form.get("name", "").strip()
        department = request.form.get("department", "").strip()
        semester = request.form.get("semester", "").strip()
        course_ids = request.form.getlist("course_ids", type=int)
        if not name or len(name) > 100:
            flash("Please enter a valid name.", "danger")
        else:
            g.current_user.name = name
            g.current_user.department = department[:100]
            g.current_user.semester = semester[:40]
            g.current_user.courses = db.session.scalars(
                select(Course).where(Course.id.in_(set(course_ids)))
            ).all() if course_ids else []
            db.session.commit()
            flash("Your profile and active courses have been updated.", "success")
            return redirect(url_for("main.profile"))
    selected_ids = {course.id for course in g.current_user.courses}
    return render_template("profile/index.html", courses=all_courses, selected_ids=selected_ids)
