from datetime import datetime
from flask import Blueprint, flash, g, redirect, render_template, request, url_for, abort
from sqlalchemy import func, or_, and_, select
from sqlalchemy.exc import IntegrityError
from .extensions import db
from .models import Course, SessionRequest, StudySession
from .security import login_required
from .timeutils import local_now

bp = Blueprint("sessions", __name__, url_prefix="/sessions")


def parse_session_datetime(value: str):
    try:
        return datetime.fromisoformat(value)
    except (TypeError, ValueError):
        return None


@bp.route("/", methods=["GET"])
@login_required
def index():
    q = request.args.get("q", "").strip()[:100]
    course_code = request.args.get("course_code", "").strip().upper()[:30]
    scope = request.args.get("scope", "mine")
    query = select(StudySession).where(
        StudySession.session_datetime >= local_now(),
        or_(
            StudySession.status == "open",
            and_(StudySession.creator_id == g.current_user.id, StudySession.status == "full"),
        ),
    )
    courses = sorted(g.current_user.courses, key=lambda item: item.course_code)
    if scope != "all" and not course_code:
        active_ids = [course.id for course in courses]
        if active_ids:
            query = query.where(or_(StudySession.course_id.in_(active_ids), StudySession.creator_id == g.current_user.id))
        else:
            query = query.where(StudySession.creator_id == g.current_user.id)
    if course_code:
        query = query.join(Course).where(Course.course_code.ilike(f"%{course_code}%"))
    if q:
        query = query.where(
            StudySession.title.ilike(f"%{q}%") |
            StudySession.topic.ilike(f"%{q}%") |
            StudySession.location.ilike(f"%{q}%")
        )
    sessions = db.session.scalars(query.order_by(StudySession.session_datetime).limit(100)).all()
    request_rows = db.session.scalars(
        select(SessionRequest).where(SessionRequest.requester_id == g.current_user.id)
    ).all()
    my_requests = {row.session_id: row.status for row in request_rows}
    all_courses = db.session.scalars(select(Course).order_by(Course.course_code)).all()
    return render_template(
        "sessions/index.html", sessions=sessions, courses=courses,
        all_courses=all_courses, my_requests=my_requests, q=q,
        course_code=course_code, scope=scope,
    )


@bp.post("/create")
@login_required
def create():
    title = request.form.get("title", "").strip()
    topic = request.form.get("topic", "").strip()
    location = request.form.get("location", "").strip() or "Online"
    course_id = request.form.get("course_id", type=int)
    session_datetime = parse_session_datetime(request.form.get("session_datetime", ""))
    max_members = request.form.get("max_members", type=int) or 0
    enrolled_ids = {course.id for course in g.current_user.courses}
    errors = []
    if not title or len(title) > 160:
        errors.append("Enter a session title (maximum 160 characters).")
    if course_id not in enrolled_ids:
        errors.append("Choose one of your enrolled courses.")
    if session_datetime is None or session_datetime <= local_now():
        errors.append("Choose a valid future date and time.")
    if max_members < 2 or max_members > 50:
        errors.append("Member limit must be between 2 and 50, including you.")
    if errors:
        for error in errors:
            flash(error, "danger")
        return redirect(url_for("sessions.index"))
    study_session = StudySession(
        creator_id=g.current_user.id, course_id=course_id, title=title,
        topic=topic[:4000], location=location[:180], session_datetime=session_datetime,
        max_members=max_members, status="open",
    )
    db.session.add(study_session)
    db.session.commit()
    flash("Your study session has been created.", "success")
    return redirect(url_for("sessions.index"))


@bp.post("/<int:session_id>/join")
@login_required
def join(session_id):
    study_session = db.session.get(StudySession, session_id)
    if not study_session:
        abort(404)
    if study_session.creator_id == g.current_user.id:
        flash("You already own this session.", "info")
        return redirect(url_for("sessions.index"))
    if study_session.status != "open" or study_session.session_datetime <= local_now():
        flash("This session is no longer accepting requests.", "warning")
        return redirect(url_for("sessions.index"))
    accepted = db.session.scalar(select(func.count(SessionRequest.id)).where(
        SessionRequest.session_id == session_id, SessionRequest.status == "accepted"
    )) or 0
    if accepted >= study_session.max_members - 1:
        study_session.status = "full"
        db.session.commit()
        flash("This session has no available seats.", "warning")
        return redirect(url_for("sessions.index"))
    existing = db.session.scalar(select(SessionRequest).where(
        SessionRequest.session_id == session_id,
        SessionRequest.requester_id == g.current_user.id,
    ))
    if existing and existing.status != "declined":
        flash("You have already requested to join this session.", "info")
        return redirect(url_for("sessions.index"))
    if existing:
        existing.status = "pending"
        existing.created_at = local_now()
    else:
        db.session.add(SessionRequest(session_id=session_id, requester_id=g.current_user.id, status="pending"))
    try:
        db.session.commit()
        flash("Join request sent to the session creator.", "success")
    except IntegrityError:
        db.session.rollback()
        flash("Your request could not be submitted. Please try again.", "danger")
    return redirect(url_for("sessions.index"))


@bp.post("/<int:session_id>/requests/<int:request_id>/<decision>")
@login_required
def decide_request(session_id, request_id, decision):
    if decision not in {"accept", "decline"}:
        abort(404)
    # The row lock serializes concurrent approvals for the same study session in MySQL.
    study_session = db.session.execute(
        select(StudySession).where(StudySession.id == session_id).with_for_update()
    ).scalar_one_or_none()
    if not study_session:
        abort(404)
    if study_session.creator_id != g.current_user.id:
        abort(403)
    join_request = db.session.get(SessionRequest, request_id)
    if not join_request or join_request.session_id != session_id:
        abort(404)
    if join_request.status != "pending":
        flash("This request has already been reviewed.", "info")
        return redirect(url_for("sessions.index"))
    if decision == "accept":
        accepted = db.session.scalar(select(func.count(SessionRequest.id)).where(
            SessionRequest.session_id == session_id, SessionRequest.status == "accepted"
        )) or 0
        if accepted >= study_session.max_members - 1:
            study_session.status = "full"
            db.session.commit()
            flash("The session is full. No additional members can be accepted.", "warning")
            return redirect(url_for("sessions.index"))
        join_request.status = "accepted"
        if accepted + 1 >= study_session.max_members - 1:
            study_session.status = "full"
        flash("Student accepted into your session.", "success")
    else:
        join_request.status = "declined"
        accepted = db.session.scalar(select(func.count(SessionRequest.id)).where(
            SessionRequest.session_id == session_id, SessionRequest.status == "accepted"
        )) or 0
        study_session.status = "full" if accepted >= study_session.max_members - 1 else "open"
        flash("Join request declined.", "info")
    db.session.commit()
    return redirect(url_for("sessions.index"))
