from urllib.parse import urlparse
from flask import Blueprint, flash, g, redirect, request, url_for, abort, render_template
from sqlalchemy import select
from .extensions import db
from .models import Course, CourseTask
from .security import login_required

bp = Blueprint("tasks", __name__, url_prefix="/tasks")


def safe_return(default_endpoint: str):
    referrer = request.referrer
    if referrer:
        parsed = urlparse(referrer)
        if parsed.netloc == request.host and parsed.scheme in {"http", "https"}:
            return redirect(referrer)
    return redirect(url_for(default_endpoint) + "#checklist")


@bp.get("/")
@login_required
def index():
    tasks = db.session.scalars(
        select(CourseTask).where(CourseTask.user_id == g.current_user.id)
        .order_by(CourseTask.is_done, CourseTask.created_at.desc())
    ).all()
    courses = sorted(g.current_user.courses, key=lambda item: item.course_code)
    return render_template("tasks/index.html", tasks=tasks, courses=courses)


@bp.post("/create")
@login_required
def create():
    title = request.form.get("title", "").strip()
    course_id = request.form.get("course_id", type=int)
    active_ids = {course.id for course in g.current_user.courses}
    if not title or len(title) > 180:
        flash("Enter a task title (maximum 180 characters).", "danger")
    elif course_id not in active_ids:
        flash("Choose one of your enrolled courses.", "danger")
    else:
        db.session.add(CourseTask(user_id=g.current_user.id, course_id=course_id, title=title))
        db.session.commit()
        flash("Checklist item added.", "success")
    return safe_return("main.dashboard")


@bp.post("/<int:task_id>/toggle")
@login_required
def toggle(task_id):
    task = db.session.get(CourseTask, task_id)
    if not task:
        abort(404)
    if task.user_id != g.current_user.id:
        abort(403)
    task.is_done = not task.is_done
    db.session.commit()
    return safe_return("main.dashboard")


@bp.post("/<int:task_id>/delete")
@login_required
def delete(task_id):
    task = db.session.get(CourseTask, task_id)
    if not task:
        abort(404)
    if task.user_id != g.current_user.id:
        abort(403)
    db.session.delete(task)
    db.session.commit()
    flash("Checklist item deleted.", "info")
    return safe_return("main.dashboard")
