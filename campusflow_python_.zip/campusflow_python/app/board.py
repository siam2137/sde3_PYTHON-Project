from urllib.parse import urlparse
from flask import Blueprint, flash, g, redirect, render_template, request, url_for, abort
from sqlalchemy import func, select
from .extensions import db
from .models import Course, CoursePost, CourseReply
from .security import login_required

bp = Blueprint("board", __name__, url_prefix="/board")


def valid_http_url(value: str) -> bool:
    try:
        parsed = urlparse(value)
        return parsed.scheme in {"http", "https"} and bool(parsed.hostname) and not parsed.username and not parsed.password
    except ValueError:
        return False


@bp.get("/")
@login_required
def index():
    course_code = request.args.get("course_code", "").strip().upper()[:30]
    kind = request.args.get("type", "").strip()
    q = request.args.get("q", "").strip()[:100]
    query = select(CoursePost)
    active_ids = [course.id for course in g.current_user.courses]
    if course_code:
        query = query.join(Course).where(Course.course_code.ilike(f"%{course_code}%"))
    elif active_ids:
        query = query.where(CoursePost.course_id.in_(active_ids))
    else:
        query = query.where(False)
    if kind in {"question", "note_link"}:
        query = query.where(CoursePost.post_type == kind)
    if q:
        query = query.where(CoursePost.title.ilike(f"%{q}%") | CoursePost.body.ilike(f"%{q}%"))
    posts = db.session.scalars(query.order_by(CoursePost.created_at.desc()).limit(100)).all()
    courses = db.session.scalars(select(Course).order_by(Course.course_code)).all()
    return render_template("board/index.html", posts=posts, courses=courses,
                           course_code=course_code, kind=kind, q=q)


@bp.post("/create")
@login_required
def create():
    title = request.form.get("title", "").strip()
    body = request.form.get("body", "").strip()
    post_type = request.form.get("post_type", "")
    course_id = request.form.get("course_id", type=int)
    resource_url = request.form.get("resource_url", "").strip()
    active_ids = {course.id for course in g.current_user.courses}
    errors = []
    if not title or len(title) > 180:
        errors.append("Enter a title (maximum 180 characters).")
    if not body or len(body) > 10000:
        errors.append("Write a post body (maximum 10,000 characters).")
    if post_type not in {"question", "note_link"}:
        errors.append("Choose question or resource link.")
    if course_id not in active_ids:
        errors.append("Choose one of your enrolled courses.")
    if post_type == "note_link":
        if not resource_url or len(resource_url) > 2048 or not valid_http_url(resource_url):
            errors.append("Enter a valid HTTP or HTTPS resource URL.")
    else:
        resource_url = None
    if errors:
        for error in errors:
            flash(error, "danger")
        return redirect(url_for("board.index"))
    post = CoursePost(user_id=g.current_user.id, course_id=course_id,
                      post_type=post_type, title=title, body=body, resource_url=resource_url)
    db.session.add(post)
    db.session.commit()
    flash("Your post has been published.", "success")
    return redirect(url_for("board.detail", post_id=post.id))


@bp.route("/<int:post_id>", methods=["GET", "POST"])
@login_required
def detail(post_id):
    post = db.session.get(CoursePost, post_id)
    if not post:
        abort(404)
    if request.method == "POST":
        body = request.form.get("body", "").strip()
        if not body or len(body) > 5000:
            flash("Write a reply (maximum 5,000 characters).", "danger")
        else:
            db.session.add(CourseReply(post_id=post.id, user_id=g.current_user.id, body=body))
            db.session.commit()
            flash("Your reply has been added.", "success")
            return redirect(url_for("board.detail", post_id=post.id))
    return render_template("board/detail.html", post=post)


@bp.post("/<int:post_id>/delete")
@login_required
def delete(post_id):
    post = db.session.get(CoursePost, post_id)
    if not post:
        abort(404)
    if post.user_id != g.current_user.id:
        abort(403)
    db.session.delete(post)
    db.session.commit()
    flash("Your post has been deleted.", "info")
    return redirect(url_for("board.index"))
