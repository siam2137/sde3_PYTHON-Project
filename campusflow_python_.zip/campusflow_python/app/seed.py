from datetime import timedelta
from sqlalchemy import select
from .extensions import db
from .models import Course, CoursePost, CourseReply, CourseTask, Deadline, SessionRequest, StudySession, User
from .timeutils import local_now


def seed_demo():
    course_data = [
        ("CSE3292", "Software Engineering", "3rd Year"),
        ("CSE2101", "Data Structures and Algorithms", "2nd Year"),
        ("MAT1205", "Linear Algebra", "1st Year"),
        ("CSE2203", "Database Management Systems", "2nd Year"),
        ("ENG1101", "English Communication", "1st Year"),
    ]
    courses = {}
    for code, title, semester in course_data:
        course = db.session.scalar(select(Course).where(Course.course_code == code))
        if course is None:
            course = Course(course_code=code, course_title=title, semester_label=semester)
            db.session.add(course)
        courses[code] = course
    db.session.flush()

    def ensure_user(email, name, password, department="Computer Science & Engineering", semester="3rd Semester"):
        user = db.session.scalar(select(User).where(User.email == email))
        if user is None:
            user = User(name=name, email=email, department=department, semester=semester)
            user.set_password(password)
            db.session.add(user)
            db.session.flush()
        return user

    siam = ensure_user("siam@campusflow.test", "Siam Ahmed", "Campus123!")
    nadia = ensure_user("nadia@campusflow.test", "Nadia Rahman", "Study123!")
    arif = ensure_user("arif@campusflow.test", "Arif Hasan", "Project123!")
    siam.courses = [courses["CSE3292"], courses["CSE2101"], courses["CSE2203"], courses["MAT1205"]]
    nadia.courses = [courses["CSE3292"], courses["CSE2101"], courses["ENG1101"]]
    arif.courses = [courses["CSE3292"], courses["CSE2203"], courses["MAT1205"]]
    db.session.flush()

    if db.session.scalar(select(StudySession.id).limit(1)) is None:
        study1 = StudySession(
            creator_id=nadia.id, course_id=courses["CSE3292"].id,
            title="Software Engineering revision circle", topic="UML diagrams, use cases and SDLC examples",
            location="Library, Group Study Room 2", session_datetime=local_now() + timedelta(days=1, hours=2),
            max_members=5, status="open",
        )
        study2 = StudySession(
            creator_id=arif.id, course_id=courses["CSE2203"].id,
            title="SQL practice before lab", topic="JOINs, GROUP BY, subqueries and normalization",
            location="Online — Google Meet", session_datetime=local_now() + timedelta(days=2),
            max_members=4, status="open",
        )
        db.session.add_all([study1, study2])
        db.session.flush()
        db.session.add_all([
            SessionRequest(session_id=study1.id, requester_id=siam.id, status="pending"),
            SessionRequest(session_id=study2.id, requester_id=siam.id, status="accepted"),
        ])

    if db.session.scalar(select(Deadline.id).limit(1)) is None:
        db.session.add_all([
            Deadline(user_id=siam.id, course_id=courses["CSE3292"].id, title="Use case diagram submission",
                     deadline_type="assignment", due_datetime=local_now() + timedelta(hours=26)),
            Deadline(user_id=siam.id, course_id=courses["CSE2101"].id, title="Stack and Queue quiz",
                     deadline_type="quiz", due_datetime=local_now() + timedelta(hours=44)),
            Deadline(user_id=siam.id, course_id=courses["MAT1205"].id, title="Midterm examination",
                     deadline_type="exam", due_datetime=local_now() + timedelta(days=6)),
            Deadline(user_id=siam.id, course_id=courses["CSE2203"].id, title="ERD project milestone",
                     deadline_type="project", due_datetime=local_now() + timedelta(days=12)),
        ])

    if db.session.scalar(select(CoursePost.id).limit(1)) is None:
        post1 = CoursePost(
            user_id=nadia.id, course_id=courses["CSE3292"].id, post_type="question",
            title="What is the practical difference between verification and validation?",
            body="I understand the definitions, but could someone share a simple software project example that makes the difference clear?",
        )
        post2 = CoursePost(
            user_id=arif.id, course_id=courses["CSE2203"].id, post_type="note_link",
            title="My DBMS normalization notes",
            body="I made a short revision sheet covering 1NF, 2NF, 3NF and BCNF.",
            resource_url="https://example.com/dbms-normalization-notes",
        )
        db.session.add_all([post1, post2])
        db.session.flush()
        db.session.add(CourseReply(
            post_id=post1.id, user_id=siam.id,
            body="For example, verification checks whether the design follows the specification; validation checks whether the finished system solves the user's actual problem.",
        ))

    if db.session.scalar(select(CourseTask.id).limit(1)) is None:
        db.session.add_all([
            CourseTask(user_id=siam.id, course_id=courses["CSE3292"].id, title="Revise SDLC models"),
            CourseTask(user_id=siam.id, course_id=courses["CSE2101"].id, title="Practice 5 stack problems"),
            CourseTask(user_id=siam.id, course_id=courses["CSE2203"].id, title="Review database normalization", is_done=True),
        ])

    db.session.commit()
