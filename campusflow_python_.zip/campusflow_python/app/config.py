import os
from pathlib import Path
from dotenv import load_dotenv

BASE_DIR = Path(__file__).resolve().parent.parent
load_dotenv(BASE_DIR / ".env")


class Config:
    SECRET_KEY = os.getenv("SECRET_KEY", "dev-only-change-this-secret-key")
    # SQLite is the zero-configuration local default. Hosted deployments should
    # set DATABASE_URL to a persistent MySQL database connection string.
    database_url = os.getenv("DATABASE_URL")
    # Railway exposes MYSQL_URL with the mysql:// scheme. This project uses
    # PyMySQL, so tell SQLAlchemy to use that driver explicitly.
    if database_url and database_url.startswith("mysql://"):
        database_url = database_url.replace("mysql://", "mysql+pymysql://", 1)

    SQLALCHEMY_DATABASE_URI = database_url or (
        f"sqlite:///{(BASE_DIR / 'instance' / 'campusflow.db').as_posix()}"
    )
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    SQLALCHEMY_ENGINE_OPTIONS = {"pool_pre_ping": True}

    SESSION_TYPE = "filesystem"
    SESSION_PERMANENT = False
    SESSION_USE_SIGNER = True
    SESSION_COOKIE_HTTPONLY = True
    SESSION_COOKIE_SAMESITE = "Lax"
    SESSION_COOKIE_SECURE = os.getenv("COOKIE_SECURE", "false").lower() == "true"
    PERMANENT_SESSION_LIFETIME = 60 * 60 * 8

    APP_TIMEZONE = os.getenv("APP_TIMEZONE", "Asia/Dhaka")
