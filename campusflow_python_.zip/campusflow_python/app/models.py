from datetime import datetime
from werkzeug.security import generate_password_hash, check_password_hash
from .extensions import db
from .timeutils import local_now


user_courses = db.Table(
    "user_courses",
    db.Column("user_id", db.Integer, db.ForeignKey("users.id", ondelete="CASCADE"), primary_key=True),
    db.Column("course_id", db.Integer, db.ForeignKey("courses.id", ondelete="CASCADE"), primary_key=True),
)


class User(db.Model):
    __tablename__ = "users"

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(190), nullable=False, unique=True, index=True)
    password_hash = db.Column(db.String(255), nullable=False)
    department = db.Column(db.String(100), nullable=False, default="")
    semester = db.Column(db.String(40), nullable=False, default="")
    created_at = db.Column(db.DateTime, nullable=False, default=local_now)

    courses = db.relationship("Course", secondary=user_courses, back_populates="students")
    study_sessions = db.relationship("StudySession", back_populates="creator", cascade="all, delete-orphan")
    deadlines = db.relationship("Deadline", back_populates="user", cascade="all, delete-orphan")
    posts = db.relationship("CoursePost", back_populates="author", cascade="all, delete-orphan")
    tasks = db.relationship("CourseTask", back_populates="user", cascade="all, delete-orphan")

    def set_password(self, password: str) -> None:
        self.password_hash = generate_password_hash(password)

    def check_password(self, password: str) -> bool:
        return check_password_hash(self.password_hash, password)


class Course(db.Model):
    __tablename__ = "courses"

    id = db.Column(db.Integer, primary_key=True)
    course_code = db.Column(db.String(30), nullable=False, unique=True, index=True)
    course_title = db.Column(db.String(180), nullable=False)
    semester_label = db.Column(db.String(40), nullable=False, default="")

    students = db.relationship("User", secondary=user_courses, back_populates="courses")
    study_sessions = db.relationship("StudySession", back_populates="course")
    deadlines = db.relationship("Deadline", back_populates="course")
    posts = db.relationship("CoursePost", back_populates="course")
    tasks = db.relationship("CourseTask", back_populates="course")

    @property
    def label(self) -> str:
        return f"{self.course_code} — {self.course_title}"


class StudySession(db.Model):
    __tablename__ = "study_sessions"
    __table_args__ = (
        db.CheckConstraint("max_members >= 2", name="ck_session_min_members"),
        db.CheckConstraint("status IN ('open', 'full', 'closed')", name="ck_session_status"),
        db.Index("ix_sessions_course_datetime", "course_id", "session_datetime"),
    )

    id = db.Column(db.Integer, primary_key=True)
    creator_id = db.Column(db.Integer, db.ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    course_id = db.Column(db.Integer, db.ForeignKey("courses.id", ondelete="RESTRICT"), nullable=False, index=True)
    title = db.Column(db.String(160), nullable=False)
    topic = db.Column(db.Text, nullable=False, default="")
    location = db.Column(db.String(180), nullable=False, default="Online")
    session_datetime = db.Column(db.DateTime, nullable=False, index=True)
    max_members = db.Column(db.Integer, nullable=False, default=4)
    status = db.Column(db.String(16), nullable=False, default="open", index=True)
    created_at = db.Column(db.DateTime, nullable=False, default=local_now)

    creator = db.relationship("User", back_populates="study_sessions")
    course = db.relationship("Course", back_populates="study_sessions")
    requests = db.relationship("SessionRequest", back_populates="study_session", cascade="all, delete-orphan")

    @property
    def accepted_count(self) -> int:
        return sum(1 for request in self.requests if request.status == "accepted")

    @property
    def available_slots(self) -> int:
        # max_members includes the creator.
        return max(0, self.max_members - 1 - self.accepted_count)


class SessionRequest(db.Model):
    __tablename__ = "session_requests"
    __table_args__ = (
        db.UniqueConstraint("session_id", "requester_id", name="uq_session_requester"),
        db.CheckConstraint("status IN ('pending', 'accepted', 'declined')", name="ck_request_status"),
        db.Index("ix_session_requests_status", "session_id", "status"),
    )

    id = db.Column(db.Integer, primary_key=True)
    session_id = db.Column(db.Integer, db.ForeignKey("study_sessions.id", ondelete="CASCADE"), nullable=False)
    requester_id = db.Column(db.Integer, db.ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    status = db.Column(db.String(16), nullable=False, default="pending")
    created_at = db.Column(db.DateTime, nullable=False, default=local_now)

    study_session = db.relationship("StudySession", back_populates="requests")
    requester = db.relationship("User")


class Deadline(db.Model):
    __tablename__ = "deadlines"
    __table_args__ = (
        db.CheckConstraint("type IN ('exam', 'assignment', 'quiz', 'project')", name="ck_deadline_type"),
        db.Index("ix_deadlines_user_due", "user_id", "due_datetime"),
    )

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    course_id = db.Column(db.Integer, db.ForeignKey("courses.id", ondelete="RESTRICT"), nullable=False)
    title = db.Column(db.String(180), nullable=False)
    deadline_type = db.Column("type", db.String(20), nullable=False)
    due_datetime = db.Column(db.DateTime, nullable=False, index=True)
    is_completed = db.Column(db.Boolean, nullable=False, default=False)

    user = db.relationship("User", back_populates="deadlines")
    course = db.relationship("Course", back_populates="deadlines")


class CoursePost(db.Model):
    __tablename__ = "course_posts"
    __table_args__ = (
        db.CheckConstraint("post_type IN ('question', 'note_link')", name="ck_post_type"),
        db.Index("ix_course_posts_course_created", "course_id", "created_at"),
    )

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    course_id = db.Column(db.Integer, db.ForeignKey("courses.id", ondelete="RESTRICT"), nullable=False)
    post_type = db.Column(db.String(20), nullable=False)
    title = db.Column(db.String(180), nullable=False)
    body = db.Column(db.Text, nullable=False)
    resource_url = db.Column(db.String(2048), nullable=True)
    created_at = db.Column(db.DateTime, nullable=False, default=local_now)

    author = db.relationship("User", back_populates="posts")
    course = db.relationship("Course", back_populates="posts")
    replies = db.relationship("CourseReply", back_populates="post", cascade="all, delete-orphan", order_by="CourseReply.created_at")


class CourseReply(db.Model):
    __tablename__ = "course_replies"

    id = db.Column(db.Integer, primary_key=True)
    post_id = db.Column(db.Integer, db.ForeignKey("course_posts.id", ondelete="CASCADE"), nullable=False, index=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    body = db.Column(db.Text, nullable=False)
    created_at = db.Column(db.DateTime, nullable=False, default=local_now)

    post = db.relationship("CoursePost", back_populates="replies")
    author = db.relationship("User")


class CourseTask(db.Model):
    __tablename__ = "course_tasks"
    __table_args__ = (db.Index("ix_tasks_user_course", "user_id", "course_id"),)

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    course_id = db.Column(db.Integer, db.ForeignKey("courses.id", ondelete="RESTRICT"), nullable=False)
    title = db.Column(db.String(180), nullable=False)
    is_done = db.Column(db.Boolean, nullable=False, default=False)
    created_at = db.Column(db.DateTime, nullable=False, default=local_now)

    user = db.relationship("User", back_populates="tasks")
    course = db.relationship("Course", back_populates="tasks")
