import os
from flask import Flask, abort, g, render_template, request
from .config import Config
from .extensions import db, server_session
from .security import csrf_token, load_current_user, validate_csrf


def create_app(config_object=Config):
    app = Flask(__name__, instance_relative_config=True)
    app.config.from_object(config_object)
    os.makedirs(app.instance_path, exist_ok=True)
    app.config["SESSION_FILE_DIR"] = os.path.join(app.instance_path, "flask_session")
    os.makedirs(app.config["SESSION_FILE_DIR"], exist_ok=True)

    db.init_app(app)
    server_session.init_app(app)

    from .auth import bp as auth_bp
    from .main import bp as main_bp
    from .sessions import bp as sessions_bp
    from .deadlines import bp as deadlines_bp
    from .board import bp as board_bp
    from .tasks import bp as tasks_bp

    app.register_blueprint(auth_bp)
    app.register_blueprint(main_bp)
    app.register_blueprint(sessions_bp)
    app.register_blueprint(deadlines_bp)
    app.register_blueprint(board_bp)
    app.register_blueprint(tasks_bp)

    @app.before_request
    def before_request():
        load_current_user()
        if request.method in {"POST", "PUT", "PATCH", "DELETE"}:
            validate_csrf()

    @app.context_processor
    def inject_globals():
        return {"current_user": getattr(g, "current_user", None), "csrf_token": csrf_token}

    @app.errorhandler(400)
    def bad_request(error):
        return render_template("errors/error.html", code=400,
                               message=getattr(error, "description", "The request could not be processed.")), 400

    @app.errorhandler(403)
    def forbidden(error):
        return render_template("errors/error.html", code=403,
                               message="You don't have permission to access this item."), 403

    @app.errorhandler(404)
    def not_found(error):
        return render_template("errors/error.html", code=404,
                               message="We couldn't find the page or item you're looking for."), 404

    @app.cli.command("init-db")
    def init_db_command():
        """Create the database tables."""
        with app.app_context():
            db.create_all()
        print("CampusFlow database tables created.")

    @app.cli.command("seed-demo")
    def seed_demo_command():
        """Insert the sample courses, accounts and example content."""
        from .seed import seed_demo
        with app.app_context():
            db.create_all()
            seed_demo()
        print("CampusFlow demo data is ready.")

    return app
