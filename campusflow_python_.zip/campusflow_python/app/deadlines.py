import calendar
from datetime import date, datetime
from flask import Blueprint, flash, g, redirect, render_template, request, url_for, abort
from sqlalchemy import select
from .extensions import db
from .models import Course, Deadline
from .security import login_required
from .timeutils import local_now

bp = Blueprint("deadlines", __name__, url_prefix="/deadlines")
ALLOWED_TYPES = {"exam", "assignment", "quiz", "project"}


def parse_month(value: str | None) -> date:
    try:
        year, month = map(int, (value or "").split("-", 1))
        return date(year, month, 1)
    except (ValueError, TypeError):
        today = local_now().date()
        return date(today.year, today.month, 1)


@bp.get("/")
@login_required
def index():
    month = parse_month(request.args.get("month"))
    start = datetime(month.year, month.month, 1)
    if month.month == 12:
        next_month = datetime(month.year + 1, 1, 1)
    else:
        next_month = datetime(month.year, month.month + 1, 1)
    rows = db.session.scalars(select(Deadline).where(
        Deadline.user_id == g.current_user.id,
        Deadline.due_datetime >= start,
        Deadline.due_datetime < next_month,
    ).order_by(Deadline.due_datetime)).all()
    events_by_day = {}
    for item in rows:
        events_by_day.setdefault(item.due_datetime.day, []).append(item)
    weeks = calendar.Calendar(firstweekday=0).monthdayscalendar(month.year, month.month)
    prev_month = date(month.year - (month.month == 1), 12 if month.month == 1 else month.month - 1, 1)
    next_month_date = date(month.year + (month.month == 12), 1 if month.month == 12 else month.month + 1, 1)
    upcoming = db.session.scalars(select(Deadline).where(
        Deadline.user_id == g.current_user.id,
        Deadline.is_completed.is_(False),
        Deadline.due_datetime >= local_now(),
    ).order_by(Deadline.due_datetime).limit(12)).all()
    courses = sorted(g.current_user.courses, key=lambda item: item.course_code)
    return render_template(
        "deadlines/index.html", month=month, weeks=weeks, events_by_day=events_by_day,
        prev_month=prev_month, next_month=next_month_date, upcoming=upcoming, courses=courses, today=local_now().date(),
    )


@bp.post("/create")
@login_required
def create():
    title = request.form.get("title", "").strip()
    course_id = request.form.get("course_id", type=int)
    deadline_type = request.form.get("type", "")
    try:
        due_datetime = datetime.fromisoformat(request.form.get("due_datetime", ""))
    except (TypeError, ValueError):
        due_datetime = None
    active_ids = {course.id for course in g.current_user.courses}
    errors = []
    if not title or len(title) > 180:
        errors.append("Enter a deadline title (maximum 180 characters).")
    if course_id not in active_ids:
        errors.append("Choose one of your enrolled courses.")
    if deadline_type not in ALLOWED_TYPES:
        errors.append("Choose a valid deadline type.")
    if due_datetime is None:
        errors.append("Choose a valid due date and time.")
    if errors:
        for error in errors:
            flash(error, "danger")
        return redirect(url_for("deadlines.index"))
    db.session.add(Deadline(
        user_id=g.current_user.id, course_id=course_id, title=title,
        deadline_type=deadline_type, due_datetime=due_datetime, is_completed=False,
    ))
    db.session.commit()
    flash("Deadline added to your calendar.", "success")
    return redirect(url_for("deadlines.index", month=due_datetime.strftime("%Y-%m")))


@bp.post("/<int:deadline_id>/toggle")
@login_required
def toggle(deadline_id):
    item = db.session.get(Deadline, deadline_id)
    if not item:
        abort(404)
    if item.user_id != g.current_user.id:
        abort(403)
    item.is_completed = not item.is_completed
    db.session.commit()
    flash("Deadline status updated.", "success")
    return redirect(url_for("deadlines.index", month=item.due_datetime.strftime("%Y-%m")))


@bp.post("/<int:deadline_id>/delete")
@login_required
def delete(deadline_id):
    item = db.session.get(Deadline, deadline_id)
    if not item:
        abort(404)
    if item.user_id != g.current_user.id:
        abort(403)
    month = item.due_datetime.strftime("%Y-%m")
    db.session.delete(item)
    db.session.commit()
    flash("Deadline deleted.", "info")
    return redirect(url_for("deadlines.index", month=month))
