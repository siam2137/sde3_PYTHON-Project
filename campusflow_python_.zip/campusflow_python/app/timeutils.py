import os
from datetime import datetime
from zoneinfo import ZoneInfo


def local_now() -> datetime:
    """Return a timezone-local naive datetime for storage and HTML datetime-local inputs."""
    zone_name = os.getenv("APP_TIMEZONE", "Asia/Dhaka")
    try:
        zone = ZoneInfo(zone_name)
    except Exception:
        zone = ZoneInfo("Asia/Dhaka")
    return datetime.now(zone).replace(tzinfo=None)
